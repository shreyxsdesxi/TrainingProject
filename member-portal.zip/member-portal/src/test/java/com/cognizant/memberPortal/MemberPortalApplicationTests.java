package com.cognizant.memberPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
